const Config = {
    // Put here your firebase configuration
    apiKey: "AIzaSyBBwjIYNbZjQeDzSxNWYjEz6sBXSXJEfts",
    authDomain: "ionic4firebase-st.firebaseapp.com",
    databaseURL: "https://ionic4firebase-st.firebaseio.com",
    projectId: "ionic4firebase-st",
    storageBucket: "ionic4firebase-st.appspot.com",
    messagingSenderId: "5463921528",
    appId: "1:5463921528:web:c9887fad2069e9fd"
};

export default Config;
