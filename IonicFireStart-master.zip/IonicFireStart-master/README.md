# Follow me on github!

<img src="https://github.com/dvidd/Ionic-4-firebase/blob/master/ionic4-c.png?raw=true">

# Ionic 4 Firebase Kit Login Register

Ionic 4 & firebase multiplatform started kit with login and register with firebase
This is a simple way to get a register and login with ionic 4 and firebase, we use the new router module.

Make the login and register fast

## demo : https://app-firebase-started.web.app/


## Setup firebase 

You have to allow authoritation and enable gmail login and email and password like this :

<img src="https://github.com/davidbarrero38/Ionic-4-firebase/blob/master/src/assets/Captura%20de%20pantalla%202019-01-25%20a%20las%200.27.48.png?raw=true">

Then you chat to put your firebase configuration to the /src/firebase.ts file 

## Desing and UI

This is how the app looks 

<br>


<img src="https://github.com/daviddbarrero/Ionic-4-firebase/blob/master/src/assets/all1.png">

<br>

## Setup


* npm install 

* ionic serve 

You can tested in Ionic <a href="https://ionicframework.com/docs/appflow/devapp/">Ionic devapp</a>


## demo : https://app-firebase-started.web.app/



## TODO 

* Social media main page
* Profile with @ 
* Explore page
* Follow post

